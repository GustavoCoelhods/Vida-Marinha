let questions = [
    {
    numb: 1,
    question: "Qual o maior mamífero do oceano",
    answer: "Baleia Azul",
    options: [
      "Baleia Azul",
      "Peixe Boi",
      "Baleia Jubarte",
      "Leão Marinho"
    ]
  },
    {
    numb: 2,
    question: "Qual a maior tartaruga marinha?",
    answer: "Tartaruga de couro",
    options: [
      "Tartaruga de pente",
      "Tartaruga oliva",
      "Tartaruga de couro",
      "Tartaruga verde"
    ]
  },
    {
    numb: 3,
    question: "Qual oceano é o mais poluido do mundo?",
    answer: "Oceano Pacífico",
    options: [
      "Oceano Índico",
      "Oceano Pacífico",
      "Oceano Ártico",
      "Oceano Atlântico"
    ]
  },
    {
    numb: 4,
    question: "Qual animal se habita na fauna brasileira?",
    answer: "Peixe Boi",
    options: [
      "Raia",
      "Orca",
      "Tubarão Baleia",
      "Peixe Boi"
    ]
  },
    {
    numb: 5,
    question: "Qual o tipo de lixo mais jogado nos oceanos?",
    answer: "Plástico",
    options: [
      "Plástico",
      "Vidro",
      "Isopor",
      "Canudo"
    ]
  },
];